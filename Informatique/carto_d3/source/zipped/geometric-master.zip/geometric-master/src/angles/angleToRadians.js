// Converts degrees to radians.
export function angleToRadians(angle){
  return angle / 180 * Math.PI;
}