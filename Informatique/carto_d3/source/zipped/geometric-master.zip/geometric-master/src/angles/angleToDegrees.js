// Converts radians to degrees.
export function angleToDegrees(angle){
  return angle * 180 / Math.PI;
}